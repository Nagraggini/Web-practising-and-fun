document.addEventListener("DOMContentLoaded", function () {
  //alert("Üdvözöllek az oldalon!"); // Egy felugró üzenet az oldal betöltésekor
});
